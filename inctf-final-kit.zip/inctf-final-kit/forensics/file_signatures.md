# Common File Signatures

| Bytes | Meaning |
|---|---|
| `50 4B 03 04` | ZIP |
| `89 50 4E 47 0D 0A 1A 0A` | PNG |
| `FF D8 FF` | JPEG |
| `25 50 44 46` | PDF |
| `7F 45 4C 46` | ELF |
| `4D 5A` | Windows PE/DOS executable |
| `1F 8B` | gzip |
| `42 5A 68` | bzip2 |
| `FD 37 7A 58 5A 00` | xz |

If the extension and signature disagree, trust the signature.
