#!/usr/bin/env bash
set -u

TARGET="${1:?Usage: ./triage.sh TARGET}"

echo "=== FILE ==="
file "$TARGET"

echo
echo "=== EXIFTOOL ==="
if command -v exiftool >/dev/null 2>&1; then exiftool "$TARGET"; else echo "exiftool not installed"; fi

echo
echo "=== STRINGS ==="
strings -a "$TARGET" | head -n 200

echo
echo "=== HEAD HEX ==="
xxd "$TARGET" | head -n 20

echo
echo "=== TAIL HEX ==="
xxd "$TARGET" | tail -n 20

echo
echo "=== BINWALK ==="
if command -v binwalk >/dev/null 2>&1; then binwalk "$TARGET"; else echo "binwalk not installed"; fi
