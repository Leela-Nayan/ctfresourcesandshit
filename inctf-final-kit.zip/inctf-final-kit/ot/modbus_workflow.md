# OT/ICS Quick Workflow

## 1. Identify protocol

Do not assume Modbus just because it is industrial.

Look at:
- TCP/UDP port
- packet structure
- protocol dissector
- function codes
- device/vendor hints

## 2. Modbus TCP

Typical port:
`502/tcp`

Common function codes:
- 01 Read Coils
- 02 Read Discrete Inputs
- 03 Read Holding Registers
- 04 Read Input Registers
- 05 Write Single Coil
- 06 Write Single Register
- 0F Write Multiple Coils
- 10 Write Multiple Registers

## 3. Where a CTF flag may hide

Try in this order:
1. register values
2. register addresses
3. coil states as bits
4. concatenated register values
5. ordering/timing
6. suspicious writes

Registers are 16-bit values. Test both byte orders when converting to text.

## 4. Wireshark

Filter:
`modbus`

Then:
- inspect function codes
- follow TCP stream
- note address ranges
- note reads vs writes
- extract values

## 5. Script

For a raw packet:
```bash
python3 ot/modbus_hex.py "000100000006010300000004"
```

For register values:
```bash
python3 ot/modbus_register_ascii.py 0x696e 0x6374
```
