#!/usr/bin/env python3
"""
Turn 16-bit Modbus register values into possible ASCII.

Usage:
  python3 modbus_register_ascii.py 0x696e 0x6374 0x66...
"""
import argparse

p = argparse.ArgumentParser()
p.add_argument("registers", nargs="+", type=lambda x: int(x,0))
args = p.parse_args()

be = b"".join(x.to_bytes(2,"big") for x in args.registers)
le = b"".join(x.to_bytes(2,"little") for x in args.registers)

print("big-endian bytes :", be)
print("little-endian bytes:", le)
