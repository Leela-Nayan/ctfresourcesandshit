#!/usr/bin/env python3
"""
Decode a single Modbus TCP ADU supplied as hex.

MBAP = transaction(2) protocol(2) length(2) unit(1)
PDU  = function(1) + data

This is a parser, not an exploit.
"""
import argparse

p = argparse.ArgumentParser()
p.add_argument("hex_adu")
args = p.parse_args()

b = bytes.fromhex(args.hex_adu.replace(":", "").replace(" ", ""))
if len(b) < 8:
    raise SystemExit("Too short for a Modbus TCP ADU.")

tid = int.from_bytes(b[0:2], "big")
pid = int.from_bytes(b[2:4], "big")
length = int.from_bytes(b[4:6], "big")
unit = b[6]
fc = b[7]

names = {
    1:"Read Coils",2:"Read Discrete Inputs",3:"Read Holding Registers",
    4:"Read Input Registers",5:"Write Single Coil",6:"Write Single Register",
    15:"Write Multiple Coils",16:"Write Multiple Registers"
}

print("transaction:", tid)
print("protocol:", pid)
print("length:", length)
print("unit:", unit)
print("function:", f"0x{fc:02x}", names.get(fc, "Unknown"))

data = b[8:]
if fc in (1,2,3,4) and len(data) >= 4:
    start = int.from_bytes(data[0:2], "big")
    qty = int.from_bytes(data[2:4], "big")
    print("start/address:", start)
    print("quantity:", qty)
elif fc in (5,6) and len(data) >= 4:
    addr = int.from_bytes(data[0:2], "big")
    value = int.from_bytes(data[2:4], "big")
    print("address:", addr)
    print("value:", value)
else:
    print("PDU data:", data.hex())
