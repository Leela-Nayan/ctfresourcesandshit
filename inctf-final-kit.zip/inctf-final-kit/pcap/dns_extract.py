#!/usr/bin/env python3
"""
Extract DNS query names from a PCAP using tshark.

Usage:
  python3 dns_extract.py capture.pcap example.com

The script prints labels immediately before the supplied domain.
"""
import argparse, subprocess

p = argparse.ArgumentParser()
p.add_argument("pcap")
p.add_argument("--domain", default="")
args = p.parse_args()

cmd = [
    "tshark", "-r", args.pcap,
    "-Y", "dns.qry.name",
    "-T", "fields", "-e", "dns.qry.name"
]
out = subprocess.check_output(cmd, text=True, errors="replace")
names = [x.strip() for x in out.splitlines() if x.strip()]

for name in names:
    print(name)

if args.domain:
    print("\n=== labels before domain ===")
    suffix = "." + args.domain.lstrip(".")
    for name in names:
        if name.endswith(suffix):
            label = name[:-len(suffix)]
            if label:
                print(label)
