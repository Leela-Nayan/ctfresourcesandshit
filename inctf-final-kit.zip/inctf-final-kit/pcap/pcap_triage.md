# PCAP Triage

## First pass

1. Open in Wireshark.
2. Statistics -> Protocol Hierarchy.
3. Statistics -> Conversations.
4. Look at endpoints.
5. Filter obvious protocols.
6. Follow streams.
7. Export transferred objects.

## Useful filters

```text
http
dns
icmp
tcp
udp
ftp
ssh
tls
modbus
usb.capdata
tcp.stream eq 0
ip.addr == 10.0.0.5
tcp.port == 80
udp.port == 53
```

## Follow streams

Right-click a TCP packet:
Follow -> TCP Stream

Look for:
- HTTP requests/responses
- credentials
- commands
- base64/hex-looking strings
- files
- unusual protocol fields

## Export objects

File -> Export Objects -> HTTP/SMB/etc.

## Covert channels

### DNS
Long/random subdomains can contain encoded data:
`aGVsbG8gd29ybGQ.example.com`

### ICMP
Look for unusually large payloads, nonstandard repeating patterns, or payloads that concatenate into a file.

### Timing/order
If payloads look meaningless, compare:
- packet order
- lengths
- intervals
- repeated event types

### USB HID
Filter:
`usb.capdata`

Then decode HID report bytes using a standard keyboard scan-code mapping.
