#!/usr/bin/env python3
"""
Extract ICMP payloads from a PCAP with tshark.

Usage:
  python3 icmp_extract.py capture.pcap > payloads.txt

Review the concatenated output for file signatures, base encodings, etc.
"""
import argparse, subprocess, binascii

p = argparse.ArgumentParser()
p.add_argument("pcap")
args = p.parse_args()

cmd = [
    "tshark", "-r", args.pcap,
    "-Y", "icmp.data",
    "-T", "fields", "-e", "icmp.data"
]
out = subprocess.check_output(cmd, text=True, errors="replace")

buf = bytearray()
for line in out.splitlines():
    h = line.strip().replace(":", "")
    if not h:
        continue
    try:
        buf.extend(bytes.fromhex(h))
    except ValueError:
        print("Skipping malformed payload:", line)

print("Total bytes:", len(buf))
print(buf.hex())
print("\nRaw:")
print(bytes(buf))
