#!/usr/bin/env python3
"""
Basic USB HID boot-keyboard decoder.

Input: hex report bytes, e.g.:
00 04 00 00 00 00 00 00

This covers standard US keyboard usage IDs. For unusual layouts, extend MAP.
"""
import argparse

MAP = {
    0x04:'a',0x05:'b',0x06:'c',0x07:'d',0x08:'e',0x09:'f',0x0a:'g',
    0x0b:'h',0x0c:'i',0x0d:'j',0x0e:'k',0x0f:'l',0x10:'m',0x11:'n',
    0x12:'o',0x13:'p',0x14:'q',0x15:'r',0x16:'s',0x17:'t',0x18:'u',
    0x19:'v',0x1a:'w',0x1b:'x',0x1c:'y',0x1d:'z',
    0x1e:'1',0x1f:'2',0x20:'3',0x21:'4',0x22:'5',0x23:'6',
    0x24:'7',0x25:'8',0x26:'9',0x27:'0',
    0x28:'\n',0x2c:' ',0x2d:'-',0x2e:'=',0x2f:'[',0x30:']',
    0x33:';',0x34:"'",0x35:'`',0x36:',',0x37:'.',0x38:'/'
}
SHIFT = 0x02

p = argparse.ArgumentParser()
p.add_argument("hex_reports", nargs="+")
args = p.parse_args()

for raw in args.hex_reports:
    b = bytes.fromhex(raw)
    if len(b) < 3:
        continue
    mods = b[0]
    for usage in b[2:]:
        if usage == 0:
            continue
        ch = MAP.get(usage, f"<0x{usage:02x}>")
        if mods & SHIFT and len(ch) == 1:
            ch = ch.upper()
        print(ch, end="")
print()
