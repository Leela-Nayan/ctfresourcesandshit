# CTF Workflow — Beginner Under Pressure

## 1. Read before touching anything

Ask:
1. What exactly did I receive?
2. What does the description emphasize?
3. What is unusual?
4. What information did the author deliberately give me?
5. Is there source code?
6. Is there an oracle/service?
7. Is there a file, PCAP, memory dump, or protocol?

## 2. The loop

Observe -> Hypothesis -> Search concept -> Test -> Interpret -> Repeat

A failed test is information.

## 3. Search strategy

Search the *technical symptom*, not the challenge name.

Examples:
- `n e c RSA e=3 CTF`
- `ECDSA nonce bounded lattice CTF`
- `LCG recover a c m outputs`
- `OU encryption additive homomorphic oracle`
- `Wireshark extract DNS payload`
- `Modbus function code 03 register ASCII`

Use public writeups as pattern dictionaries:
1. Stop before the solution.
2. Predict the first step.
3. Read the first step.
4. Ask why it was chosen.
5. Continue.

## 4. Time management

- 0–2 min: identify object + likely category
- 2–5 min: obvious tests
- 5–10 min: targeted research
- 10–15 min: if no progress, park it and communicate your hypothesis

Do not spend 45 minutes proving that your first guess was wrong.

## 5. Source-code triage

For crypto Python/Sage, search first for:
`random`, `randint`, `getrandbits`, `seed`, `nonce`, `k`, `key`, `iv`, `n`, `e`, `d`, `p`, `q`, `sign`, `verify`, `encrypt`, `decrypt`, `oracle`, `query`.

For every custom algorithm ask:
- What is standard?
- What did the author change?
- Does that change reduce entropy?
- Does it reveal information?
- Can I choose inputs?
- Is there reuse?
- Is there a bound?

## 6. Oracle mindset

If a service lets you:
- encrypt chosen plaintexts
- sign chosen messages
- verify signatures
- query decryption
- request tickets/tokens

write down:
- what inputs are accepted
- what inputs are blacklisted
- what output is returned
- whether the response leaks success/failure
- whether repeated queries are allowed
- whether the primitive is malleable

Then search for the primitive + the observed weakness.

## 7. Team communication

Say:
> "I think this is RSA because n/e/c are provided. e=3 looks suspicious. I am checking low-exponent/broadcast cases."

Not:
> "I am stuck."

Give the team your current hypothesis and evidence.
