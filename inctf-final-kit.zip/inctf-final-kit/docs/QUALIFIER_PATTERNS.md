# Qualifier Pattern Index

These are the three patterns supplied in the team's 2026 writeup channel.

## 1. Okamoto-Uchiyama oracle
Core idea: additive homomorphism / malleability.

Do not hard-code a target challenge. Build the algebra from the exact encryption equation.

## 2. LCG ticket generator
Core idea: recover LCG parameters from successive outputs, then reverse the recurrence.

Use:
- `crypto/lcg_recover.py`
- `crypto/lcg_backtrack.py`

Always verify recovered parameters against an output not used for recovery.

## 3. ECDSA bounded nonce
Core idea: bounded nonce -> lattice attack -> private-key recovery -> signature forgery.

Use `crypto/ecdsa_bounded_nonce.sage` as a starting framework, but derive the exact lattice equations from the challenge's nonce bound/leakage model.

## Why these matter

These three examples cover three very different recurring crypto ideas:
- homomorphic oracle manipulation
- weak PRNG/state recovery
- signature nonce leakage

The common skill is reading the implementation and attacking the broken assumption.
