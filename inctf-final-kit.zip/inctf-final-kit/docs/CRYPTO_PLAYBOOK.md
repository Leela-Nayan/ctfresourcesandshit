# Crypto Playbook

## A. Encoding / classical

### Identify
- hex: `[0-9a-fA-F]`, even length
- base64: `A-Za-z0-9+/` with optional `=`
- base32: uppercase + `2-7`, often `=`
- binary: mostly 0/1
- URL encoding: `%xx`
- Caesar/ROT: readable after fixed shifts

Use CyberChef if available, but understand what it did.

## B. XOR

### Single byte
Try all 256 keys and score plaintext.

```bash
python3 crypto/xor_single_byte.py ciphertext.hex
```

### Repeating key
If key is short/reused:
1. estimate key length
2. split ciphertext by key position
3. solve each column as single-byte XOR
4. rebuild plaintext

```bash
python3 crypto/xor_repeating.py ciphertext.hex
```

## C. RSA triage

Given `n,e,c`:
1. Is `n` small/factorable?
2. Is `e` unusually small?
3. Is the same message encrypted under multiple moduli?
4. Is `n` reused?
5. Is `p`/`q`/`dp`/`dq` leaked?
6. Is `d` unusually small?
7. Are there chosen-message/signing/decryption oracles?
8. Is the implementation using textbook RSA without padding?

Useful helpers:
- `rsa_factor_fermat.py`
- `rsa_hastad.py`
- `rsa_common_modulus.py`
- `rsa_wiener.py`
- `rsa_dp_leak.py`

## D. LCG

Standard recurrence:
`x_(n+1) = (a*x_n + c) mod m`

If successive outputs are visible and modulus/parameters are unknown:
- recover parameters
- verify against additional outputs
- reverse state if required

```bash
python3 crypto/lcg_recover.py 123 456 789 101112 131415
```

## E. ECDSA

Never reuse nonce `k`.

If same `r` appears for two signatures:
- nonce reuse is strongly suspected
- recover `k`
- recover private key
- forge target signature

If nonce is bounded:
- collect enough signatures
- use a lattice attack
- exact equations depend on the leakage model

Use:
- `ecdsa_nonce_reuse.py`
- `ecdsa_bounded_nonce.sage`

## F. Homomorphic encryption

If oracle blocks a target plaintext:
- identify whether encryption is additive/multiplicative homomorphic
- derive an algebraic relation
- encrypt allowed messages
- combine ciphertexts
- undo any known transformation

For an additive scheme:
`E(m1) * E(m2) = E(m1 + m2)`
and
`E(m)^k = E(km)`.

Do not blindly apply this to a different scheme; verify the exact operation.

## G. Discrete logarithm

If group is small:
- brute force
- baby-step giant-step
- Pohlig-Hellman if group order factors smoothly

`bsgs.py` provides a generic integer-group helper.

Polynomial finite-field challenges may require Sage.

## H. AES / block ciphers

Identify:
- key
- IV/nonce
- mode
- padding
- encoding

Common CTF weaknesses:
- ECB pattern leakage
- IV reuse
- nonce reuse
- predictable key
- key/IV supplied in source
- custom mode mistakes

## I. Custom crypto

Compare:
- textbook algorithm
- exact challenge implementation

Write down every difference. The difference is often the bug.
