# Pre-Competition Tool Request Checklist

Before the finals, verify what the organizers already provide.

## Highest priority

- Python 3
- pip packages needed by your scripts
- Wireshark
- tshark
- exiftool
- binwalk
- steghide
- zsteg
- OpenSSL
- Volatility 3
- SageMath
- Ghidra

## Ask explicitly about

- Git access
- GitHub access
- browser/public documentation access
- whether you may use preloaded custom scripts
- whether scripts can include third-party Python packages
- whether Sage scripts are permitted
- whether binaries such as RsaCtfTool are permitted
- whether package installation during the event is prohibited
- whether internet access is restricted per challenge

Keep this checklist in your repo so the team can verify the environment before the timer starts.
