# InCTF Pattern Notes

These notes are based on publicly available InCTF writeups/resources and the qualifier writeups supplied for preparation.

## Current 2026 material

The official 2026 writeup index includes Crypto challenges such as:
- ACE
- exclusive-OR
- QuadRSAtic
- Triple Prime
- subtRSAtic
- Oh_No_Hastad
- Dp
- Renege

and Forensics challenges such as:
- Corrupt
- Finding Data
- Tweak Me
- Dark Wave
- Easy Peasy
- Track Me
- VIBGYOR
- White House.

The official resources also include introductory cryptography and forensics material.

## Qualifier patterns supplied for this preparation

### Okamoto-Uchiyama encryption oracle
Observed pattern:
- encryption oracle
- forbidden plaintext
- additively homomorphic encryption
- multiplication of ciphertexts corresponds to addition of plaintexts
- exponentiation of ciphertext corresponds to multiplication of plaintext by a constant

Recognition:
> "I cannot ask the oracle to encrypt the target message, but I can make related ciphertexts."

Action:
1. Identify the exact homomorphism.
2. Find an allowed plaintext relation to the forbidden plaintext.
3. Transform ciphertexts algebraically.
4. Verify locally with the challenge implementation.
5. Only then automate interaction.

### LCG ticket generator
Observed pattern:
- successive ticket outputs are visible
- LCG parameters are hidden
- recover `a, c, m` from consecutive outputs
- reverse the recurrence to obtain earlier state/output
- use recovered historical value to answer the challenge

Recognition:
> "Repeated outputs from a linear recurrence."

Action:
- collect 3+ outputs; more is better
- run `crypto/lcg_recover.py`
- verify recovered parameters on unused outputs
- reverse the state
- only then query/submit

### ECDSA bounded nonce
Observed pattern:
- signing oracle
- target message is blocked
- nonce `k` is bounded
- bounded nonce leaks enough information for a lattice attack
- recover private key
- forge target signature

Recognition:
> "ECDSA + nonce bound = lattice territory."

Action:
- collect many signatures with chosen messages
- record `(r,s,z)` and any stated/observed nonce bounds
- determine exact curve/order
- use Sage/fpylll-based lattice tooling
- verify recovered key against a known signature
- forge the forbidden target message

Do not assume one lattice script works for every curve or nonce leakage model. Match the script to the exact equations from the challenge.

## Older InCTF patterns worth recognizing

### InCTF 2021
Public writeups include:
- ECDH with severely reduced private-key space due to broken randomness
- custom RNG leakage
- Jacobi-symbol bit leakage
- advanced BLS signature material

### InCTF 2020
Public writeups include:
- polynomial RSA over finite fields
- discrete logarithms in polynomial quotient rings
- ECDSA/signing-oracle weaknesses
- custom PRNG/elliptic-curve constructions

### What this suggests

The recurring lesson is NOT "memorize every cryptosystem."

It is:
1. Read the implementation.
2. Identify what assumption the primitive relies on.
3. Look for a broken assumption.
4. Search the exact primitive + weakness.
5. Use a known mathematical attack/script.
