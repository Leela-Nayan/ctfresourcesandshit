# InCTF Final Offline Kit

A competition-time reference and script kit for **Crypto, Forensics/PCAP, and OT/ICS**.

## What this is

This repo is designed for a finals machine where:
- AI/remote assistance is prohibited.
- Public documentation/writeups may be allowed by the event rules.
- You may need to preload scripts/tools before the event.
- You need fast "what do I try next?" guidance.

**Do not use any script against systems outside the authorized CTF environment.**

## 30-second triage

### Crypto
- `n, e, c` -> RSA
- small/odd `e` -> inspect low-exponent/broadcast possibilities
- repeated `n` -> shared-prime / common-modulus possibilities
- `d` or `dp` leaked -> key-recovery attacks
- multiple ciphertexts of same message -> broadcast/common-modulus
- repeated/short XOR key -> XOR analysis
- weird RNG / LCG -> recover parameters/state
- signing oracle -> inspect nonce generation, reuse, bounds, message restrictions
- encryption oracle -> inspect malleability / homomorphism
- custom crypto -> compare implementation with the standard algorithm

### Forensics
Start with:
```bash
file TARGET
strings -a TARGET | less
exiftool TARGET
xxd TARGET | head
xxd TARGET | tail
binwalk TARGET
```

### PCAP
Start with:
- Protocol Hierarchy
- Conversations
- Follow TCP Stream
- HTTP/DNS/ICMP/USB/Modbus filters
- Export Objects
- suspicious packet lengths/timing/ordering

### OT
- TCP 502 -> inspect Modbus TCP
- identify function codes
- inspect register/coil values
- inspect addresses too
- check for ASCII packed into 16-bit registers
- check coil states as bits
- look for suspicious writes

## Golden rule

**Do not search the challenge name first. Search the symptom/concept.**

Good:
- `RSA e=3 CTF`
- `ECDSA bounded nonce lattice`
- `LCG parameter recovery CTF`
- `Okamoto Uchiyama homomorphic encryption oracle`
- `Wireshark DNS exfiltration`
- `Modbus register ASCII CTF`

Bad:
- `"ChallengeName" flag writeup`

## Repo map

- `docs/` — competition workflows and pattern notes
- `crypto/` — reusable crypto solvers/helpers
- `forensics/` — file triage and artifact helpers
- `pcap/` — packet extraction helpers
- `ot/` — Modbus/ICS helpers
- `scripts/` — machine/tool checks
- `requirements/` — packages to request/preinstall

## Important

These are **templates and reusable techniques**, not guaranteed one-click solvers. Always inspect the challenge implementation first.
