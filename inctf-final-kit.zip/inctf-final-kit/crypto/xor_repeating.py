#!/usr/bin/env python3
import argparse
import string

def hamming(a, b):
    return sum((x ^ y).bit_count() for x, y in zip(a, b))

def score(pt):
    printable = sum(c in bytes(string.printable, "ascii") for c in pt)
    spaces = pt.count(32)
    letters = sum((65 <= c <= 90) or (97 <= c <= 122) for c in pt)
    return printable + 2*spaces + 0.15*letters

def single_byte_xor(block):
    best = None
    for k in range(256):
        pt = bytes(x ^ k for x in block)
        item = (score(pt), k, pt)
        if best is None or item[0] > best[0]:
            best = item
    return best

p = argparse.ArgumentParser()
p.add_argument("hex_ciphertext")
p.add_argument("--max-keylen", type=int, default=40)
args = p.parse_args()

ct = bytes.fromhex(args.hex_ciphertext)
candidates = []
for klen in range(1, min(args.max_keylen, len(ct)//2) + 1):
    chunks = [ct[i:i+klen] for i in range(0, min(len(ct), 4*klen), klen)]
    if len(chunks) < 2:
        continue
    distances = []
    for a, b in zip(chunks, chunks[1:]):
        distances.append(hamming(a, b) / max(1, len(a)))
    candidates.append((sum(distances)/len(distances), klen))

print("Likely key lengths:")
for d, klen in sorted(candidates)[:10]:
    print(f"  {klen:2d}  normalized-distance={d:.3f}")

for _, klen in sorted(candidates)[:3]:
    key = bytearray()
    for i in range(klen):
        block = ct[i::klen]
        _, k, _ = single_byte_xor(block)
        key.append(k)
    pt = bytes(c ^ key[i % klen] for i, c in enumerate(ct))
    print(f"\nkeylen={klen} key={bytes(key)!r}\n{pt!r}")
