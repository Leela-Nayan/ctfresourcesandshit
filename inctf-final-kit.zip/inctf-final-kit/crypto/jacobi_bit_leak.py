#!/usr/bin/env python3
"""
Decode a sequence of ciphertexts where Jacobi symbol encodes one bit.

This is a generic helper for schemes where:
  Jacobi(c, N) == +1 -> 0
  otherwise -> 1

It is NOT a universal cryptosystem solver; verify the challenge's exact mapping.
"""
import argparse
import math

try:
    import sympy as sp
except ImportError:
    sp = None

p = argparse.ArgumentParser()
p.add_argument("N", type=int)
p.add_argument("ciphertexts", nargs="+", type=int)
args = p.parse_args()

if sp is None:
    raise SystemExit("Install sympy or implement the Jacobi symbol locally.")

bits = []
for c in args.ciphertexts:
    j = int(sp.jacobi(c, args.N))
    bits.append("0" if j == 1 else "1")

bitstr = "".join(bits)
value = int(bitstr, 2)
raw = value.to_bytes((value.bit_length()+7)//8, "big")
print(bitstr)
print(raw)
