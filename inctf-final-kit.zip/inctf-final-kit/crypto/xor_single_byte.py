#!/usr/bin/env python3
import argparse
import string

COMMON = b" etaoinshrdluETAOINSHRDLU"

def score(pt: bytes) -> float:
    printable = sum(c in bytes(string.printable, "ascii") for c in pt)
    spaces = pt.count(b" ")
    letters = sum((65 <= c <= 90) or (97 <= c <= 122) for c in pt)
    return printable * 1.0 + spaces * 2.0 + letters * 0.15

p = argparse.ArgumentParser()
p.add_argument("hex_ciphertext")
p.add_argument("-n", "--top", type=int, default=10)
args = p.parse_args()

ct = bytes.fromhex(args.hex_ciphertext)
results = []
for k in range(256):
    pt = bytes(b ^ k for b in ct)
    results.append((score(pt), k, pt))

for s, k, pt in sorted(results, reverse=True)[:args.top]:
    print(f"key=0x{k:02x} score={s:.2f} plaintext={pt!r}")
