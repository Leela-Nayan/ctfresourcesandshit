#!/usr/bin/env python3
import argparse

p = argparse.ArgumentParser()
p.add_argument("a", type=int)
p.add_argument("c", type=int)
p.add_argument("m", type=int)
p.add_argument("current", type=int)
p.add_argument("-n", "--count", type=int, default=1)
args = p.parse_args()

ainv = pow(args.a, -1, args.m)
x = args.current
for i in range(args.count):
    x = (ainv * (x - args.c)) % args.m
    print(x)
