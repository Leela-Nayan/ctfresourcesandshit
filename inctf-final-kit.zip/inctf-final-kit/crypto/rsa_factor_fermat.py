#!/usr/bin/env python3
import argparse, math

p = argparse.ArgumentParser()
p.add_argument("n", type=int)
p.add_argument("--max-steps", type=int, default=5_000_000)
args = p.parse_args()

n = args.n
a = math.isqrt(n)
if a*a < n:
    a += 1

for i in range(args.max_steps):
    b2 = a*a - n
    b = math.isqrt(b2)
    if b*b == b2:
        p1, p2 = a-b, a+b
        print("p =", p1)
        print("q =", p2)
        print("steps =", i)
        break
    a += 1
else:
    print("No close factors found in the configured search window.")
