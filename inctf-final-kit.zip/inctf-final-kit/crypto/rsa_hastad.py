#!/usr/bin/env python3
"""
Håstad-style broadcast helper.

Input: same plaintext m encrypted with e small across >= e coprime moduli:
c_i = m^e mod n_i

The CRT result is m^e as an ordinary integer when m^e < product(n_i).
"""
import argparse
from Crypto.Util.number import integer_nthroot, long_to_bytes

def crt(items):
    N = 1
    for n, _ in items:
        N *= n
    x = 0
    for n, c in items:
        Ni = N // n
        x += c * Ni * pow(Ni, -1, n)
    return x % N

p = argparse.ArgumentParser()
p.add_argument("e", type=int)
p.add_argument("pairs", nargs="+", help="n:c pairs")
args = p.parse_args()

items = []
for pair in args.pairs:
    n, c = pair.split(":", 1)
    items.append((int(n), int(c)))

if len(items) < args.e:
    raise SystemExit("Need at least e ciphertext/modulus pairs for the classic broadcast case.")

M = crt(items)
root, exact = integer_nthroot(M, args.e)
print("exact integer root:", exact)
print("m =", root)
print("bytes =", long_to_bytes(root))
