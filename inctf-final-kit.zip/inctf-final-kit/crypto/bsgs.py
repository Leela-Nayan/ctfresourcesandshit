#!/usr/bin/env python3
"""
Baby-step giant-step for a multiplicative group modulo prime p.

Find x such that g^x = h (mod p), for x in [0, order).
"""
import argparse, math

p = argparse.ArgumentParser()
p.add_argument("g", type=int)
p.add_argument("h", type=int)
p.add_argument("mod", type=int)
p.add_argument("--order", type=int, required=True)
args = p.parse_args()

m = math.isqrt(args.order) + 1
table = {}
e = 1
for j in range(m):
    table.setdefault(e, j)
    e = (e * args.g) % args.mod

factor = pow(pow(args.g, m, args.mod), -1, args.mod)
gamma = args.h

for i in range(m + 1):
    if gamma in table:
        x = i*m + table[gamma]
        if x < args.order and pow(args.g, x, args.mod) == args.h:
            print("x =", x)
            break
    gamma = (gamma * factor) % args.mod
else:
    print("No solution found in the supplied order.")
