#!/usr/bin/env python3
"""
Common modulus attack:
same n, same plaintext m, coprime exponents e1/e2:
c1=m^e1 mod n, c2=m^e2 mod n.

Find a,b with a*e1+b*e2=1, then m=c1^a*c2^b mod n.
Negative exponents are handled with modular inverses.
"""
import argparse
from Crypto.Util.number import long_to_bytes

def egcd(a,b):
    if b == 0:
        return (a,1,0)
    g,x1,y1 = egcd(b,a%b)
    return g,y1,x1-(a//b)*y1

def signed_pow(x, k, n):
    if k >= 0:
        return pow(x,k,n)
    return pow(pow(x,-1,n),-k,n)

p = argparse.ArgumentParser()
p.add_argument("n", type=int)
p.add_argument("e1", type=int)
p.add_argument("c1", type=int)
p.add_argument("e2", type=int)
p.add_argument("c2", type=int)
args = p.parse_args()

g,a,b = egcd(args.e1,args.e2)
if g != 1:
    raise SystemExit("e1 and e2 must be coprime.")

m = (signed_pow(args.c1,a,args.n) * signed_pow(args.c2,b,args.n)) % args.n
print("a =", a, "b =", b)
print("m =", m)
print("bytes =", long_to_bytes(m))
