#!/usr/bin/env python3
"""
Recover an ECDSA private key when the same nonce k was reused.

Signature equation:
s = k^-1 (z + r*d) mod n

For two signatures with the same k (same r):
k = (z1-z2)/(s1-s2) mod n
d = (s1*k-z1)/r mod n

Inputs are integer r,s,z values and the curve order n.
"""
import argparse

p = argparse.ArgumentParser()
p.add_argument("order", type=int, help="ECDSA subgroup order n")
p.add_argument("r", type=int)
p.add_argument("s1", type=int)
p.add_argument("z1", type=int)
p.add_argument("s2", type=int)
p.add_argument("z2", type=int)
args = p.parse_args()

if args.s1 == args.s2:
    raise SystemExit("s1 == s2; cannot invert the denominator.")

k = ((args.z1 - args.z2) * pow(args.s1 - args.s2, -1, args.order)) % args.order
d = ((args.s1*k - args.z1) * pow(args.r, -1, args.order)) % args.order

print("k =", k)
print("private key d =", d)
