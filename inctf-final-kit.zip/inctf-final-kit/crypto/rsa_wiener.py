#!/usr/bin/env python3
"""
Wiener's attack for textbook RSA when private exponent d is sufficiently small.

Usage:
  python3 rsa_wiener.py n e

This implementation is intentionally compact and uses continued fractions.
"""
import argparse, math
from Crypto.Util.number import long_to_bytes

def convergents(num, den):
    cf = []
    while den:
        q, r = divmod(num, den)
        cf.append(q)
        num, den = den, r
    out = []
    p_nm2, p_nm1 = 0, 1
    q_nm2, q_nm1 = 1, 0
    for a in cf:
        p = a*p_nm1 + p_nm2
        q = a*q_nm1 + q_nm2
        out.append((p,q))
        p_nm2,p_nm1 = p_nm1,p
        q_nm2,q_nm1 = q_nm1,q
    return out

p = argparse.ArgumentParser()
p.add_argument("n", type=int)
p.add_argument("e", type=int)
p.add_argument("--ciphertext", type=int)
args = p.parse_args()

for k,d in convergents(args.e, args.n):
    if k == 0:
        continue
    ed_minus_1 = args.e*d - 1
    if ed_minus_1 % k:
        continue
    phi = ed_minus_1 // k
    s = args.n - phi + 1
    disc = s*s - 4*args.n
    if disc >= 0:
        t = math.isqrt(disc)
        if t*t == disc and (s+t)%2 == 0:
            p1 = (s+t)//2
            q1 = (s-t)//2
            if p1*q1 == args.n:
                print("Recovered p,q:", p1,q1)
                print("d =", d)
                if args.ciphertext is not None:
                    m = pow(args.ciphertext,d,args.n)
                    print("plaintext =", long_to_bytes(m))
                break
else:
    print("Wiener attack did not recover a valid factorization.")
