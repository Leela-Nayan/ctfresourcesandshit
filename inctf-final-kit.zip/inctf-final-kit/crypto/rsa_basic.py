#!/usr/bin/env python3
import argparse
from math import gcd
from sympy import factorint
from Crypto.Util.number import long_to_bytes

p = argparse.ArgumentParser()
p.add_argument("n", type=int)
p.add_argument("e", type=int)
p.add_argument("c", type=int)
args = p.parse_args()

f = factorint(args.n)
print("factorization:", f)

if len(f) != 2 or any(exp != 1 for exp in f.values()):
    raise SystemExit("This helper expects n=p*q with two distinct prime factors.")

primes = list(f.keys())
P, Q = primes
phi = (P-1)*(Q-1)
if gcd(args.e, phi) != 1:
    raise SystemExit("e is not invertible modulo phi(n).")

d = pow(args.e, -1, phi)
m = pow(args.c, d, args.n)
print("p =", P)
print("q =", Q)
print("d =", d)
print("plaintext int =", m)
print("plaintext bytes =", long_to_bytes(m))
