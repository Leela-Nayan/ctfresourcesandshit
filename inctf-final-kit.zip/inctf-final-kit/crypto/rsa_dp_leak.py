#!/usr/bin/env python3
"""
Recover RSA factor p when dp = d mod (p-1) is leaked.

If m^e*dp == m (mod p), then p divides m^(e*dp)-m.
Thus gcd(m^(e*dp)-m, n) can reveal p for a suitable small m.

Usage:
  python3 rsa_dp_leak.py n e dp [m]
"""
import argparse, math

p = argparse.ArgumentParser()
p.add_argument("n", type=int)
p.add_argument("e", type=int)
p.add_argument("dp", type=int)
p.add_argument("--m", type=int, default=2)
args = p.parse_args()

x = (pow(args.m, args.e * args.dp, args.n) - args.m) % args.n
p_factor = math.gcd(x, args.n)

if p_factor in (1, args.n):
    raise SystemExit("This m did not expose a non-trivial factor; try another small m.")
q_factor = args.n // p_factor

print("p =", p_factor)
print("q =", q_factor)
print("phi =", (p_factor-1)*(q_factor-1))
