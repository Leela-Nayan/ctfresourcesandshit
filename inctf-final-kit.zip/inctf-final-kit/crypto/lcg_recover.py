#!/usr/bin/env python3
"""
Recover parameters of x_(i+1) = (a*x_i + c) mod m.

With unknown modulus m, this classic construction uses:
  t_i = x_(i+1)-x_i
  z_i = t_(i+2)*t_i - t_(i+1)^2
and m divides every z_i.

This helper recovers a likely m from gcds, then a,c.
"""
import argparse, math
from functools import reduce

p = argparse.ArgumentParser()
p.add_argument("outputs", nargs="+", type=int)
args = p.parse_args()

xs = args.outputs
if len(xs) < 6:
    raise SystemExit("Provide at least 6 successive outputs; more is strongly recommended.")

ts = [xs[i+1]-xs[i] for i in range(len(xs)-1)]
zs = []
for i in range(len(ts)-2):
    zs.append(abs(ts[i+2]*ts[i] - ts[i+1]*ts[i+1]))

m = reduce(math.gcd, [z for z in zs if z])
if m <= 0:
    raise SystemExit("Could not recover a positive modulus candidate.")

# Search a few nearby divisors/multiples because output sequences can contain degeneracies.
candidates = [m]
# Exact m is normally the gcd, but the gcd can be a multiple of the true modulus.
# Try small divisors as well.
for d in range(1, min(10000, math.isqrt(m)) + 1):
    if m % d == 0:
        candidates.extend([d, m//d])

for mod in sorted(set(candidates)):
    if mod <= max(xs):
        continue
    a = ((xs[2]-xs[1]) * pow(xs[1]-xs[0], -1, mod)) % mod if math.gcd(xs[1]-xs[0], mod)==1 else None
    if a is None:
        continue
    c = (xs[1] - a*xs[0]) % mod
    if all((a*xs[i] + c) % mod == xs[i+1] % mod for i in range(len(xs)-1)):
        print("m =", mod)
        print("a =", a)
        print("c =", c)
        print("Verification: OK")
        print("\nTo step backward when gcd(a,m)=1:")
        print("a_inv =", pow(a, -1, mod))
        print("x_previous = a_inv * (x_current - c) mod m")
        break
else:
    print("No candidate passed verification. Collect more outputs.")
