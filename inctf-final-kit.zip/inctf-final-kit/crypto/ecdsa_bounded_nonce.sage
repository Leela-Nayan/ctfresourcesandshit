# ECDSA bounded-nonce lattice TEMPLATE
#
# IMPORTANT:
# There is no single universal lattice script for every bounded-nonce model.
# Adapt the equations to the challenge's exact leakage.
#
# Standard ECDSA:
#   s_i = k_i^{-1}(z_i + r_i*d) mod n
# so:
#   k_i = (z_i + r_i*d)*s_i^{-1} mod n
#
# If k_i is known to lie in a small interval, this becomes a Hidden Number
# Problem / lattice problem. The exact basis depends on the leakage model.
#
# Recommended workflow:
# 1. Confirm curve and subgroup order n.
# 2. Collect many (r,s,z) signatures.
# 3. Confirm the challenge really bounds k.
# 4. Convert each signature equation into the exact HNP relation.
# 5. Build the lattice with Sage/fpylll.
# 6. Recover candidate d values.
# 7. Verify d against ALL known signatures before forging anything.
#
# Useful public references:
# - Howgrave-Graham & Smart, "Lattice attacks on digital signature schemes"
# - Boneh & Venkatesan, Hidden Number Problem
#
# Do NOT blindly paste a random lattice script: wrong scaling, wrong modulus,
# or wrong nonce model will produce plausible-looking garbage.
