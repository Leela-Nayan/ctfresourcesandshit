#!/usr/bin/env python3
import argparse
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

p = argparse.ArgumentParser()
p.add_argument("key_hex")
p.add_argument("ciphertext_hex")
p.add_argument("--iv-hex")
p.add_argument("--mode", choices=["cbc","ecb"], default="cbc")
args = p.parse_args()

key = bytes.fromhex(args.key_hex)
ct = bytes.fromhex(args.ciphertext_hex)

if args.mode == "ecb":
    cipher = AES.new(key, AES.MODE_ECB)
else:
    if not args.iv_hex:
        raise SystemExit("CBC requires --iv-hex")
    cipher = AES.new(key, AES.MODE_CBC, bytes.fromhex(args.iv_hex))

pt = cipher.decrypt(ct)
try:
    pt = unpad(pt, AES.block_size)
except ValueError:
    pass
print(pt)
