#!/usr/bin/env bash
set +e

echo "=== BASIC ==="
for x in python3 openssl file strings xxd grep find; do
  printf "%-14s" "$x"
  command -v "$x" || echo "MISSING"
done

echo
echo "=== FORENSICS ==="
for x in exiftool binwalk steghide zsteg; do
  printf "%-14s" "$x"
  command -v "$x" || echo "MISSING"
done

echo
echo "=== NETWORK ==="
for x in wireshark tshark; do
  printf "%-14s" "$x"
  command -v "$x" || echo "MISSING"
done

echo
echo "=== CRYPTO / RE ==="
for x in sage RsaCtfTool hashcat john ghidra; do
  printf "%-14s" "$x"
  command -v "$x" || echo "MISSING"
done

echo
echo "=== PYTHON PACKAGES ==="
python3 - <<'PY'
mods = ["Crypto", "sympy", "gmpy2", "scapy", "ecdsa"]
for m in mods:
    try:
        __import__(m)
        print(f"{m:12} OK")
    except Exception as e:
        print(f"{m:12} MISSING")
PY
